import UIKit

//closures with multiples parameters

func daysOfWeek(action: (String, String, Int) -> String){
    let message = action("you", "me", 35)
    print(message)
    return
}

daysOfWeek{ // This is the "action"
    let n = $2 + 5
    let m : String = "\($0) and \($1) are \(n) years old"
    return m
}

//Return closures from function
func travel() -> (String) -> Void { //first -> is for the fuction, the 2 is for the closure
    return {
        print("I'm going to \($0)")
    }
}

let result = travel()
result("London")

//capturing values


func travel2() -> (String) -> Void {
    var counter = 1

    return {
        print("\(counter). I'm going to \($0)")
        counter += 1
    }
}

let result2 = travel2()
result2("London")
