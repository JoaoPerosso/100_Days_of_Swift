import UIKit

//Function
func age(bornYear: Int, actualYear: Int) -> Int {
    let age = actualYear - bornYear
    return age
}

//Function returning more than one data
age(bornYear: 2005, actualYear: 2025)

func age2(bornYear: Int, actualYear: Int) -> Set<Int> {
    let age = actualYear - bornYear
    let data = Set([bornYear, actualYear, age])
    return data
}

age2(bornYear: 2005, actualYear: 2025)




func getUser() -> [String: String] {
    ["first": "Taylor", "last": "Swift"]
}

let user = getUser()
print(user["first"])


//Parameter labels

func saySomething(word say: String){ //A same variable can has two names, word -> External, say-> Internal
    print("You are \(say)") // You use as 'say'
}

saySomething(word: "Hello") //You atribute to word

//Omiting parameters labels

func triple(_ number: Int) -> Int{
    return number * 3
}

triple(34)

//Default parameters in function

func greet(nickname: String, isNice: Bool = true, male: Bool = true){
    if(isNice){
        print("The \(nickname) is the best person in the world")
    }else{
        if(male){
            print("The \(nickname) is a terrible person, I don't like he")
        }else{
            print("The \(nickname) is a terrible person, I don't like she")
        }
    }
}

greet(nickname: "josh",isNice: false)

//Variadic functions
//Infinity parameters on a function
func multiplication(numbers: Int...) -> Int{
    var result = 1
    for number in numbers {
        result *= number
    }
    return result
}

let result = multiplication(numbers: 1, 4, 5, 6, 8)

//Throws

enum PasswordError: Error {
    case obvious
}

func checkPassword(_ password: String) throws -> Bool {
    if password == "password" {
        throw PasswordError.obvious
    }

    return true
}

do {
    try checkPassword("password")
    print("That password is good!")
} catch {
    print("You can't use that password.")
}


//inout
//Change a value of a var outside the function

func changeValue(_ num: inout Int){
    num = 65
}

var tree = 3

changeValue(&tree)
