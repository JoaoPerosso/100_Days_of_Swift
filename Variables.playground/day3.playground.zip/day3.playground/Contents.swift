import UIKit

var name = "Joao"
var lastName = "Perosso"

name += lastName

//Comparison


let firstScore = 1
let secondScore = 3

firstScore == secondScore
firstScore != secondScore
firstScore < secondScore
firstScore >= secondScore


//Condictions

let firstCard = 11
let secondCard = 10

if firstCard + secondCard == 2 {
    print("Aces – lucky!")
} else if firstCard + secondCard == 21 {
    print("Blackjack!")
} else {
    print("Regular cards")
}

//Combining condictions

let age1 = 12
let age2 = 21

if age1 > 18 && age2 > 18 {
    print("Both are over 18")
}

if age1 > 18 || age2 > 18 {
    print("At least one is over 18")
}

//The ternary operator

let n1 = 10
let n2 = 200

print(n1 == n2 ? "The numbers are equal" : "The numbers are really different")

print((n1+n2) < 100 ? "The add of the numbers has just 2 digits" : "The add of the numbers has 3 or more digits")


//Switch

let weather = "Clean"

switch weather {
    case "Sunny":
    print("Go for a walk!")
case "Rainy":
    print("Stay indoors!")
case "Clean":
    print("It's a good day for karting!")
default:
    print("I need to open the doors and look to the sky!")
}

//Range operators

let score = 85

switch score { // ..< exclude the final number, ... include the final number
case 0..<50:
    print("You failed badly.")
case 50..<85:
    print("You did OK.")
default:
    print("You did great!")
}
