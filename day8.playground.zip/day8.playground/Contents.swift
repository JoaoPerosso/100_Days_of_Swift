import UIKit

//structs

struct instrument{
    var name: String
}

var myInstrument = instrument(name: "Violao")

print(myInstrument.name)

//computed properties
  
struct person{
    var firstName: String
    var isAtletic: Bool
    
    var atleticStatus: String{
        if isAtletic{
            return "\(firstName) is atletic"
        }else{
            return "\(firstName) is no atletic"
        }
        
    }
}

var joseDog = person(firstName: "joseDog", isAtletic: true)

print(joseDog.atleticStatus)
