import UIKit

//structs

struct instrument{
    var name: String
}

var myInstrument = instrument(name: "Violao")

print(myInstrument.name)

//computed properties
  
struct person{
    var firstName: String
    var isAtletic: Bool
    
    var atleticStatus: String{
        if isAtletic{
            return "\(firstName) is atletic"
        }else{
            return "\(firstName) is no atletic"
        }
        
    }
}

var joseDog = person(firstName: "joseDog", isAtletic: true)

print(joseDog.atleticStatus)

//property observes

struct Progress{
    var task: String
    var counter: Int {
        didSet{ //This will run everytime that the variable counter change
            print("counter was muted: \(counter)")
        }
    }
}

var progress = Progress(task: "Matar sapos cegos", counter: 1)
progress.counter = 2
progress.counter = 3
progress.counter = 4

//Methods
struct City {
    var population: Int

    func collectTaxes() -> Int { //Methods is func inside a struct
        return population * 1000
    }
}

let london = City(population: 9_000_000)
london.collectTaxes()

//mutating methods
struct Person2 {
    var name: String

    mutating func makeAnonymous() {//U have to put mutating if your method will change the values of the struct
        name = "Anonymous"
    }
}
var person2 = Person2(name: "Ed")
person2.makeAnonymous()


//properties and methods of Strings
let string = "Do or do not, there is no try." //Strings are structs
print(string.count)
print(string.hasPrefix("Do"))
print(string.uppercased())
print(string.sorted())

//properties and methods of arrays
var toys = ["Woody"]
print(toys.count)
toys.append("Buzz")
toys.firstIndex(of: "Buzz")
print(toys.sorted())
toys.remove(at: 0)


