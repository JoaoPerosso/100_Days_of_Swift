import UIKit

//For loops

let count = 1...10 //Declare a range

for number in count{
    print(number)
}

let names: [String] = ["Alice", "Bob", "Charlie"]

for name in names{
    print(name)
}


//while loops

var num = 1

while num <= 5{
    print(num)
    num *= 2
}

//Do whiles

var x = 0

repeat{
    print(x)
    x = 1
}while x == 0

//Exiting loops

var down = 10

while down >= 0 {
    print(down)
    down -= 1
}

//Exiting multiples loops



outloop: for x in 1...10{
    insideloop: for y in 1...10{
        print("x e y:" + String(x) + " e " + String(y))
        
        if(x == 7 && y == 3){
            break outloop
        }
    }
}

//Skipping items

for i in 1...10 {
    if i % 2 == 1 {
        continue
    }

    print(i)
}
