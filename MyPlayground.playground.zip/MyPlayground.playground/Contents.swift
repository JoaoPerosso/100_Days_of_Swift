import UIKit

//Arrays
let john = "John Lennon"
let paul = "Paul McCartney"
let george = "George Harrison"
let ringo = "Ringo Starr"

let beatles = [john, paul, george, ringo]

//Set

let colors = Set(["red", "blue", "green"]) //You can't repeat anything
let colors2 = Set(["red", "blue", "green", "red"]) //Unordered, and fast to find something

//Tuples

var name = (first: "Charlie", last: "Brown")
name.first
name.first = "Chorao"//You can't increase the size like array

//Dictionaries

let heights = [ //you need to use more than a line, because de sintax matters
    "Jacan": 1.5,
    "Giant": 4.5
]
heights["Jacan"]

//Dictionaries default values
let favoriteIceCream = [
    "Paul": "Chocolate",
    "Sophie": "Vanilla"
]
favoriteIceCream["Paul"]

favoriteIceCream["Charlotte", default: "Unknown"]

//
