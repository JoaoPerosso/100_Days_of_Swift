import UIKit

//Arrays
let john = "John Lennon"
let paul = "Paul McCartney"
let george = "George Harrison"
let ringo = "Ringo Starr"

let beatles = [john, paul, george, ringo]

//Set

let colors = Set(["red", "blue", "green"]) //You can't repeat anything
let colors2 = Set(["red", "blue", "green", "red"]) //Unordered, and fast to find something

//Tuples

var name = (first: "Charlie", last: "Brown")
name.first
name.first = "Chorao"//You can't increase the size like array

//Dictionaries

let heights = [ //you need to use more than a line, because de sintax matters
    "Jacan": 1.5,
    "Giant": 4.5
]
heights["Jacan"]

//Dictionaries default values
let favoriteIceCream = [
    "Paul": "Chocolate",
    "Sophie": "Vanilla"
]
favoriteIceCream["Paul"]

favoriteIceCream["Charlotte", default: "Unknown"]

//Empty colletions

var animals = [String : Int]()//Empty Dictionarie
animals["Dogs"] = 4
var differentDictionarie = Dictionary<String, Int>()//Different type to put the same


var emptyArray = [Int]()//Empty Array
emptyArray.append(7683798)
var results = Array<Int>()//Different type to write, but it's the same thing

var word = Set<String>()//Empty Set
word.insert("Hello")

//Enum

enum Direction { //Works to put just some answers to a var
    case north
    case south
    case east
    case west
    case distance(kilometers: Int)
}

var nextRoad = Direction.east
var travel = Direction.distance(kilometers: 234)

//Enum raw values
enum Planet: Int {
    case mercury = 1
    case venus
    case earth
    case mars
}
let earth = Planet(rawValue: 2)



