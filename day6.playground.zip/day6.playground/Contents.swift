import UIKit

//closures

let message = {
    print("I know where you live, take care...")
}
message()

//Closures with parameters

let killerMessage = { (name: String) in
    print("YOU WILL DIE \(name)")
}
killerMessage("Gustavo")

//Returning values from closures

let witnessMessage = { (face: String) -> String in
    let message = "I saw him!! His face was \(face)"
    return message
    
}

witnessMessage("Ugly")

//Closures as parameter

func gate(goal: () -> Void){
    print("I know where he was")
    goal()
    
}

let goal = {
    print("Not here!!")
}

gate(goal: goal)

//Trailing closure syntax

func travel(action: () -> Void) {
    print("I'm getting ready to go.")
    action()
    print("I arrived!")
}

travel {//The closure was pass to the func just by the name
    print("I'm driving in my car")
}
