import UIKit

//Initializers************************

//If u initialize one variable, all the variables will need to be initialize

struct Users{
    var name: String
    var age: Int
        init(){ //This will initialize all the users with a default name = Anonymous
            name = "Anonymous"
            age = -1
        }
}

var user = Users()
//print(user.name)
user.name = "John"
//print(user.name)



//Referring to the current instance***********************

struct Person {
    var name: String

    init(name: String) { //This forces me to create a person with a name
        print("\(name) was born!")
        self.name = name
    }
}//self helps you distinguish between the property and the parameter – self.name refers to the property, whereas name refers to the parameter.

//var pessoa = Person()
var pessoa = Person(name: "John")


//Lazy Properties  ***************************

struct FamilyTree {
    init() {
        print("Creating family tree!")
    }
}

struct Person3 {
    var name: String
    lazy var familyTree = FamilyTree() //The lazy makes the swift create the familyTree just on the first acess.

    init(name: String) {
        self.name = name
    }
}

var ed = Person3(name: "Ed")
//Here ed doesn't have the familyTree
ed.familyTree
//Now he has.


//Static properties and methods ***************

struct Student {
    var name: String
    static var classSize = 0 //This storage how many students the class has

    init(name: String) {
        self.name = name
        Student.classSize += 1

    }
}

let ed2 = Student(name: "Ed")
let taylor = Student(name: "Taylor")

print(Student.classSize)

//Access control ******************
//make some var private in a struct, so just a method inside the struct can get her value.


struct Person4 {
    private var id: Int

    init(id: Int) {
        self.id = id
    }

    func identify() -> String { //A method that can acess id
        return "My social security number is \(id)"
    }
}

var sergio = Person4(id: 123)
//here I can't do something like this:
// var int = sergio.id

//But I can do this:
var string = sergio.identify()
